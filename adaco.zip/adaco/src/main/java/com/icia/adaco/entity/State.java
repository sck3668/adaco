package com.icia.adaco.entity;

public enum State {
	답변대기, 답변완료 
}
