package com.icia.adaco.util.security;

public class LoginFailureHandler {

}
