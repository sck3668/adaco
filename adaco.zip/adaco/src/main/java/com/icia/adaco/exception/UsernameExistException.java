package com.icia.adaco.exception;

public class UsernameExistException extends RuntimeException {

}
