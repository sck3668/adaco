package com.icia.adaco.entity;

import lombok.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Authorities {
	private String username;
	private String authority;
}
