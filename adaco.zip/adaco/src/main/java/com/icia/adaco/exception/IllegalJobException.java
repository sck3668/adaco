package com.icia.adaco.exception;

public class IllegalJobException extends RuntimeException {

}
