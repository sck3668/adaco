package com.icia.adaco.exception;

public class QuestionNotFoundException extends RuntimeException {

}
