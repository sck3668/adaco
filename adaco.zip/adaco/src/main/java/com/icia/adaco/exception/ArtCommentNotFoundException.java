package com.icia.adaco.exception;

public class ArtCommentNotFoundException extends RuntimeException {

}
