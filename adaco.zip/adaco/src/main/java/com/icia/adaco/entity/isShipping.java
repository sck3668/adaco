package com.icia.adaco.entity;

 // 배송 상태
public enum isShipping {
	before,ongoing,After
}
