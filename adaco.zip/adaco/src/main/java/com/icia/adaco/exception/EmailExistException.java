package com.icia.adaco.exception;

public class EmailExistException extends RuntimeException {

}
