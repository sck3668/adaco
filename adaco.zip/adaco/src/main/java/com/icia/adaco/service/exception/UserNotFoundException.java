package com.icia.adaco.service.exception;

public class UserNotFoundException extends RuntimeException {

}
