package com.icia.adaco.entity;

 // 별점 추가 : 1점 ~ 5점
public enum star {
  onePoint, twoPoint, threePoint, fourPoint, fivePoint
}
