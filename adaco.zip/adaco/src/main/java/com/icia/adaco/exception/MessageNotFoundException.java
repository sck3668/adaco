package com.icia.adaco.exception;

public class MessageNotFoundException extends RuntimeException {

}
