package com.icia.adaco.service.mvc;

public class ArtCommentService {

}
