package com.icia.adaco.service.mvc;

//import org.springframework.beans.factory.annotation.*;
//import org.springframework.stereotype.*;
//import org.springframework.web.servlet.*;
//
//import com.icia.adaco.dao.*;
//
//@Service
//public class OrderDetailService {
////	@Autowired
////	private OrderDetailDao orderDetailDao; 
////	
////	// 주문하기
////	public ModelAndView Ordering()
////	
////	// 주문 취소
////	public 
////	// 모든 주문 내역 보기
////	
////	// 주문 상세 내역
//}
