package com.icia.adaco.exception;

public class OutOfStockExcetion extends RuntimeException {

}
