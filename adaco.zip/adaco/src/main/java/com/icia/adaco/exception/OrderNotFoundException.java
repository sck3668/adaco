package com.icia.adaco.exception;

import lombok.*;


public class OrderNotFoundException extends RuntimeException {


}

