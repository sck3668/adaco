package com.icia.adaco.exception;

public class ArtNotFoundException extends RuntimeException {

}
